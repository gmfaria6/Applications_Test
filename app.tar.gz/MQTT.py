# -*- coding: utf-8 -*-

import paho.mqtt.client as mqtt
import sys
import os
import requests
import json
import sys, traceback

from collections import namedtuple

Auth = namedtuple('Auth', ['user', 'pwd'])

#MQTT_ADDRESS = '172.17.0.2'
MQTT_ADDRESS = '127.0.0.1'
# descomente esta linha para usar o servidor da Fundacao Eclipse.
#MQTT_ADDRESS = 'iot.eclipse.org'
MQTT_PORT = 1883
# descomente esta linha caso seu servidor possua autenticacao.
# MQTT_AUTH = Auth('login', 'senha')
MQTT_TIMEOUT = 60

TOPICO = "/softway/iot"

if sys.version_info[0] == 3:
    input_func = input
else:
    input_func = raw_input

def on_connect(client, userdata, flags, rc):
    print('Conectado. Resultado: %s' % str(rc))
    result, mid = client.subscribe(TOPICO)
    print('Inscrevendo-se no topico' + TOPICO + '(%d)' % mid)


def on_subscribe(client, userdata, mid, granted_qos):
    print('Inscrito no topico: %d' % mid)


def on_message(client, userdata, msg):
    try:
        print('Mensagem recebida no topico: %s' % msg.topic)
        if msg.topic == TOPICO:
            print('Conteudo da mensagem: %s' % msg.payload.encode('UTF-8'))
            data = json.loads(msg.payload.encode('UTF-8'))
            r = requests.post('http://108.163.137.73/~argeucom/projects/softway4iot/public/API/lixeira', json=data)
        else:
            print('Topico desconhecido.')
    except KeyboardInterrupt:
        raise
    except:
        print "Exception in user code:"
        print '-'*60
        traceback.print_exc(file=sys.stdout)
        print '-'*60
        pass


def loop():
    while True:
        try:
            client = mqtt.Client()
            client.on_connect = on_connect
            client.on_subscribe = on_subscribe
            client.on_message = on_message
            # descomente esta linha caso seu servidor possua autenticacao.
            # client.username_pw_set(MQTT_AUTH.user, MQTT_AUTH.pwd)
            client.connect(MQTT_ADDRESS, MQTT_PORT, MQTT_TIMEOUT)
            print "server ok!"
            client.loop_forever()
        except KeyboardInterrupt:
            raise
        except:
            continue
        break


def send_message(msg):
    client = mqtt.Client()
    # descomente esta linha caso seu servidor possua autenticacao.
    # client.username_pw_set(MQTT_AUTH.user, MQTT_AUTH.pwd)
    client.connect(MQTT_ADDRESS, MQTT_PORT, MQTT_TIMEOUT)
    result, mid = client.publish(TOPICO, msg)
    print('Mensagem enviada ao canal: %d' % mid)


if __name__ == '__main__':
    if '--serve' in sys.argv:        
        print "echo.."
        loop()
    elif '--send' in sys.argv:
        msg = input_func('Digite uma mensagem:\n')
        send_message(msg)
